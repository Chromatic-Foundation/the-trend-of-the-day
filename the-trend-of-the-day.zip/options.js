document.getElementById('saveWeather').addEventListener('click', () => {
  const city = document.getElementById('cityInput').value.trim();
  if(city) {
    chrome.storage.sync.set({ weatherCity: city }, () => {
      document.getElementById('status').textContent = `City saved: ${city}`;
      // refresh weather imediat
      chrome.runtime.sendMessage({ action: 'refreshWeather' });
    });
  }
});