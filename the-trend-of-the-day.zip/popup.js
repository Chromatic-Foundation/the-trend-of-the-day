function updateUI() {
  chrome.storage.local.get([
    'cryptoPrice','topCrypto','weather','wordOfTheDay','quoteOfTheDay',
    'joke','topReddit','funFact','topSite','topVideo'
  ], data => {
    document.getElementById('cryptoPrice').textContent = data.cryptoPrice || 'Loading...';
    document.getElementById('topCrypto').textContent = data.topCrypto || 'Loading...';
    document.getElementById('weather').textContent = data.weather || 'Loading...';
    document.getElementById('wordOfTheDay').textContent = data.wordOfTheDay || 'Loading...';
    document.getElementById('quoteOfTheDay').textContent = data.quoteOfTheDay || 'Loading...';
    document.getElementById('joke').textContent = data.joke || 'Loading...';
    document.getElementById('topReddit').textContent = data.topReddit || 'Loading...';
    document.getElementById('funFact').textContent = data.funFact || 'Loading...';
    document.getElementById('topSite').textContent = data.topSite || 'Loading...';
    document.getElementById('topVideo').textContent = data.topVideo || 'Loading...';
  });
}

// Buton pentru a seta orașul la WeatherAPI
document.getElementById('setCityBtn').addEventListener('click', () => {
  const city = document.getElementById('weatherCityInput').value.trim();
  if(city) {
    chrome.storage.sync.set({ weatherCity: city }, () => {
      chrome.runtime.sendMessage({ action: 'refreshWeather' });
      updateUI();
    });
  }
});

// Actualizare UI la deschidere
updateUI();