// ====================
// BACKGROUND.JS FULL - THE TREND OF THE DAY SUPER EDITION
// ====================

// 1️⃣ Crypto - Binance Public API
function fetchCrypto() {
  fetch('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT')
    .then(res => res.json())
    .then(data => chrome.storage.local.set({ cryptoPrice: 'BTC/USDT: ' + data.price }))
    .catch(err => console.error(err));

  fetch('https://api.binance.com/api/v3/ticker/24hr')
    .then(res => res.json())
    .then(json => {
      let max = json.reduce((best, cur) =>
        parseFloat(cur.priceChangePercent) > parseFloat(best.priceChangePercent) ? cur : best
      , json[0]);
      chrome.storage.local.set({ topCrypto: max.symbol + ' ' + max.priceChangePercent + '%' });
    })
    .catch(err => console.error(err));
}

// 2️⃣ Weather - WeatherAPI.com (global)
function fetchWeather() {
  chrome.storage.sync.get(['weatherCity'], ({ weatherCity }) => {
    const city = weatherCity || 'Suceava';
    const API_KEY = '93d11f91aaf04a899f3115434262202';
    fetch(`https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${encodeURIComponent(city)}&aqi=no`)
      .then(res => res.json())
      .then(data => {
        if(data && data.current){
          const w = data.current;
          chrome.storage.local.set({
            weather: `${city}: ${w.temp_c}°C, ${w.condition.text}, Wind ${w.wind_kph} km/h`
          });
        } else {
          chrome.storage.local.set({ weather: 'Weather data unavailable' });
        }
      })
      .catch(err => {
        console.error('Error fetching weather:', err);
        chrome.storage.local.set({ weather: 'Weather data unavailable' });
      });
  });
}

// 3️⃣ Word of the Day - static fallback
function fetchWord() {
  const words = ["Inspire","Curiosity","Momentum","Bravery","Vision","Harmony","Resolve","Innovation","Focus","Clarity"];
  const word = words[Math.floor(Math.random() * words.length)];
  chrome.storage.local.set({ wordOfTheDay: word });
}

// 4️⃣ Top Sites - Chrome API
function fetchTopSites() {
  chrome.topSites.get(sites => {
    if (sites && sites.length > 0) chrome.storage.local.set({ topSite: sites[0].url });
    else chrome.storage.local.set({ topSite: 'No sites found' });
  });
}

// 5️⃣ YouTube Trending - API Key oficial
const YT_API_KEY = 'AIzaSyCskBkd396aneC-_7Lk1rI-l9w5BSAn7PI';
function fetchYouTubeTrending() {
  fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&maxResults=1&key=${YT_API_KEY}`)
    .then(res => res.json())
    .then(data => {
      if (data.items && data.items.length > 0) {
        const vid = data.items[0];
        chrome.storage.local.set({ topVideo: vid.snippet.title + ' (' + vid.statistics.viewCount + ' views)' });
      }
    })
    .catch(err => chrome.storage.local.set({ topVideo: 'Trending unavailable' }));
}

// 6️⃣ Quote of the Day
function fetchQuote() {
  fetch('https://api.quotable.io/random')
    .then(res => res.json())
    .then(data => {
      chrome.storage.local.set({ quoteOfTheDay: `"${data.content}" — ${data.author}` });
    })
    .catch(err => chrome.storage.local.set({ quoteOfTheDay: 'Quote unavailable' }));
}

// 7️⃣ Joke of the Day
function fetchJoke() {
  fetch('https://official-joke-api.appspot.com/random_joke')
    .then(res => res.json())
    .then(data => {
      chrome.storage.local.set({ joke: data.setup + ' — ' + data.punchline });
    })
    .catch(err => chrome.storage.local.set({ joke: 'Joke unavailable' }));
}

// 8️⃣ Top Reddit Post
function fetchRedditTop() {
  fetch('https://www.reddit.com/r/all/top.json?limit=1')
    .then(res => res.json())
    .then(data => {
      const post = data.data.children[0].data;
      chrome.storage.local.set({ topReddit: post.title + ' (' + post.ups + ' upvotes)' });
    })
    .catch(err => chrome.storage.local.set({ topReddit: 'No top post available' }));
}

// 9️⃣ Fun Fact
function fetchFunFact() {
  fetch('https://uselessfacts.jsph.pl/random.json?language=en')
    .then(res => res.json())
    .then(data => chrome.storage.local.set({ funFact: data.text }))
    .catch(err => chrome.storage.local.set({ funFact: 'Fact unavailable' }));
}

// ====================
// REFRESH ALL DATA
// ====================
function refreshAll() {
  fetchCrypto();
  fetchWeather();
  fetchWord();
  fetchTopSites();
  fetchYouTubeTrending();
  fetchQuote();
  fetchJoke();
  fetchRedditTop();
  fetchFunFact();
}

// Refresh imediat la start
refreshAll();

// Refresh la fiecare 30 min
setInterval(refreshAll, 1000 * 60 * 30);

// Refresh când extensia este instalată / actualizată
chrome.runtime.onInstalled.addListener(() => refreshAll());

// Refresh weather imediat după update oraș
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'refreshWeather') fetchWeather();
});