chrome.storage.sync.get(['bgColor', 'textColor'], (data) => {
    if(data.bgColor) document.body.style.backgroundColor = data.bgColor;
    if(data.textColor) document.body.style.color = data.textColor;
});